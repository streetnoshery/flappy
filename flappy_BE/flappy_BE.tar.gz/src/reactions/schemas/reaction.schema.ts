import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class Reaction extends Document {
  @Prop({ required: true })
  postId: string;

  @Prop({ required: true })
  userId: string;

  @Prop({ required: true, enum: ['love', 'laugh', 'wow', 'sad', 'angry'] })
  type: string;
}

export const ReactionSchema = SchemaFactory.createForClass(Reaction);